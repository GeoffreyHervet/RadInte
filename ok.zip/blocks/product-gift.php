<div itemscope itemtype="http://schema.org/Product" data-kind="<?php echo $kind; ?>">
    <a href="?p=product-gift" class="product">
        <span class="gift-img">
            <img  class="hidden-xs" itemprop="image" src="img/tmp/gift-list-250x325.jpg" alt="Garte cadeau" class="grayscale no-grayscale-hover"/>
            <img  class="visible-xs" src="img/tmp/gift-cell-list-250x130.jpg" alt="Garte cadeau" class="grayscale no-grayscale-hover"/>
            <span class="text-gift">
                <span class="content">CARTE CADEAU<span>10€-1000€</span></span>
            </span>
            <span class="clearfix"></span>
        </span>
        <span itemprop="name" class="name">Carte cadeau internet</span>
        <span class="price">
            10,00 € - 1000,00 €
        </span>
    </a>
    <div class="btn-actions text-uppercase">
        <a class="fast-buy" href="./">Achat rapide</a>
        <a class="save" href="./">Sauvegarder</a>
        <div class="clearfix"></div>
    </div>
</div>