'use strict';

var Rad = function(){

};

jQuery(function($){
    var rad = new Rad();
    //= require_tree components
});