;'use strict';
(function(){
    var $container = $('.img-big.visible-xs');
    if (!$container.length) {
        return ;
    }
})();